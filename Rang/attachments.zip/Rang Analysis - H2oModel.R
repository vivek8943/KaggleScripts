setwd('C:/Users/Priyank/OneDrive/Documents/MIS/Rang Technology/Source')

load('RDFiles/RTImputation_TrainAndTest.Rd')


#Factor Variables
factor_vars <- c('Cust_status','Trans24','Trans25','Trans26','Trans27','Promotion37','Active_Customer')
training.data[factor_vars] <- lapply(training.data[factor_vars], function(x) as.factor(x))
factor_vars <- c('Cust_status','Trans24','Trans25','Trans26','Trans27','Promotion37')
testing.data[factor_vars] <- lapply(testing.data[factor_vars], function(x) as.factor(x))



#required Libraries
library(h2o)

# Start h2o ,decide min and max memory sizes,number of cpu cores to be used (-1 means all cores)
localH2O <- h2o.init(ip = "localhost", port = 54321, startH2O = TRUE,
                     max_mem_size = '12g', min_mem_size = '4g', nthreads = -1)
#Training data
training.data.hex<-as.h2o(training.data)

H2ORandomForest <- h2o.randomForest(x = 2:256, y = 257 ,  training_frame = training.data.hex,
                                    model_id='H2ORandomForest')


#predict values for the Testing dataset 
testing.data.hex<-as.h2o(testing.data[,2:256])


#H2ORandomForest
H2ORandomForest.prediction.hex <- h2o.predict(H2ORandomForest, testing.data.hex)
H2ORandomForest.prediction <- as.data.frame(H2ORandomForest.prediction.hex)

?h2o.randomForest
summary(H2ORandomForest.prediction)



H2ODeepLearning <- h2o.deeplearning(x = 2:256, y = 257 ,  training_frame = training.data.hex,
                                    model_id='H2ODeepLearning')

#H2ORandomForest
H2ODeepLearning.prediction.hex <- h2o.predict(H2ODeepLearning, testing.data.hex)
H2ODeepLearning.prediction <- as.data.frame(H2ODeepLearning.prediction.hex)

?h2o.randomForest
summary(H2ODeepLearning.prediction)




